package com.pcwang.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;

import com.pcwang.entity.XmlObject;

public class ReadFile {

	public static Map<String, List<XmlObject>> readFile(String dir) throws ClassNotFoundException {
		Map<String, List<XmlObject>> objects = new HashMap<String, List<XmlObject>>();

		try {
			SAXReader reader = new SAXReader();
			List<String> pathList = GetFilePath.getPaths(dir);
			List<XmlObject> xmlObjList = null;
			List<Document> documentList = new ArrayList<Document>();
			for (String path : pathList) {
				Document document = reader.read(path);
				documentList.add(document);
			}
			
			for (Document doc : documentList) {
				List<Node> classes = doc.selectNodes("//class");
				for (Node cls : classes) {
					Element el = (Element)cls;
					String tableName = el.attributeValue("name");
					List<Node> cols = doc.selectNodes("//class[@name='"+tableName+"']/attributes/attribute");
					xmlObjList = new ArrayList<>();
					for (Node col :cols) {
						 XmlObject xmlObj = new XmlObject();
						 Element c = (Element)col;
						 String colName = c.attributeValue("name");
						 String colLabel = c.attributeValue("label");
						 String type = c.attributeValue("type");
						 String length = c.attributeValue("length");
						 String scale = c.attributeValue("scale");
						 xmlObj.setColName(colName);
						 xmlObj.setColLabel(colLabel);
						 xmlObj.setType(type);
						 xmlObj.setLength(length);
						 xmlObj.setScale(scale);
						 xmlObjList.add(xmlObj);
						 
					}
					objects.put(tableName, xmlObjList);
				}
			}
		
		} catch (DocumentException e) {
			e.printStackTrace();
		}
		return objects;
	}

}
