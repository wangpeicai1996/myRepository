package com.pcwang.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.pcwang.entity.DataObject;

public class ReadDataSource {
	
	
		//数据库连接
		private static String url = "jdbc:oracle:thin:@localhost:1521:helowin";
		//用户名
		private static String username = "rcms";
		//密码
		private static String password = "rcms";
		
		private static String driver = "oracle.jdbc.driver.OracleDriver";
		
		/**
		 * 连接数据库
		 * @return
		 * @throws ClassNotFoundException 
		 * @throws SQLException 
		 */
		public static Connection JdbcConnetion() throws ClassNotFoundException, SQLException {
			Connection connect = null;
			Class.forName(driver);
			try {
				connect=DriverManager.getConnection(url, username, password);
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("数据库连接失败");
			}
			return connect;
		}
		
		public static Map<String,Map<String,String>> queryData() throws ClassNotFoundException {
			Map<String,Map<String,String>> dataMap = new HashMap<String,Map<String,String>>();
			try {
				Connection connect = JdbcConnetion();
				String sql = "SELECT * FROM USER_COL_COMMENTS WHERE comments IS NULL ANT TABLE_NAME NOT LIKE '%$%' ORDER BY TABLE_NAME";
				PreparedStatement pstmt = connect.prepareStatement(sql);
				ResultSet rs = pstmt.executeQuery();
				//构建初始的第一个map对象
				Map<String,String> tableMap = new HashMap<String,String>();
				String tableName = "";
				String colName = "";
				String change = "1";
				while (rs.next()) {
					tableName = rs.getString("TABLE_NAME");
					colName = rs.getString("COLUMN_NAME");
					tableMap.put(colName, tableName);
					if (!change.equals(tableName)) {
						if (!"1".equals(change)) {
							//将上一个map放入大map中
							dataMap.put(change,tableMap);
						}
						change = rs.getString("TABLE_NAME");
						//构建下一个新的map
						tableMap = new HashMap<String,String>();
					}
				}
				//循环结束后，将最后一个map放入大map中
				dataMap.put(change,tableMap);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return dataMap;
		}
		
		
		public static List<String> queryTableName() throws ClassNotFoundException {
			List<String> tableList = new ArrayList<String>();
			try {
				Connection connect = JdbcConnetion();
				String sql = "SELECT table_name FROM USER_COL_COMMENTS WHERE comments IS NULL AND TABLE_NAME NOT LIKE '%$%' GROUP BY table_name";
				PreparedStatement pstmt = connect.prepareStatement(sql);
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					tableList.add(rs.getString("TABLE_NAME"));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return tableList;
		}
		

}
