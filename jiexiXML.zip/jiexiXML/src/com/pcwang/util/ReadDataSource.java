package com.pcwang.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.pcwang.entity.DataObject;

public class ReadDataSource {
	
	
		//数据库连接
		private static String url = "jdbc:oracle:thin:@localhost:1521:helowin";
		//用户名
		private static String username = "rcms";
		//密码
		private static String password = "rcms";
		
		private static String driver = "oracle.jdbc.driver.OracleDriver";
		
		/**
		 * 连接数据库
		 * @return
		 * @throws ClassNotFoundException 
		 * @throws SQLException 
		 */
		public static Connection JdbcConnetion() throws ClassNotFoundException, SQLException {
			Connection connect = null;
			Class.forName(driver);
			try {
				connect=DriverManager.getConnection(url, username, password);
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("数据库连接失败");
			}
			return connect;
		}
		
		public static List<DataObject> queryData() throws ClassNotFoundException {
			List<DataObject> dataList = new ArrayList<DataObject>();
			try {
				Connection connect = JdbcConnetion();
				String sql = "SELECT * FROM USER_COL_COMMENTS WHERE comments IS NULL";
				PreparedStatement pstmt = connect.prepareStatement(sql);
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					DataObject dataObj = new DataObject();
					dataObj.setTableName(rs.getString("TABLE_NAME"));
					dataObj.setColName(rs.getString("COLUMN_NAME"));
					dataList.add(dataObj);
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return dataList;
		}
		
		
		public static List<String> queryTableName() throws ClassNotFoundException {
			List<String> tableList = new ArrayList<String>();
			try {
				Connection connect = JdbcConnetion();
				String sql = "SELECT table_name FROM USER_COL_COMMENTS WHERE comments IS NULL AND TABLE_NAME NOT LIKE '%$%' GROUP BY table_name";
				PreparedStatement pstmt = connect.prepareStatement(sql);
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					tableList.add(rs.getString("TABLE_NAME"));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return tableList;
		}
		

}
