package com.pcwang.util;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class GetFilePath {

	
	public static List<String> getPaths(String path){
		List<String> pathList = new ArrayList<String>();
		File file = new File(path);
		File [] files = file.listFiles();
		for (int i = 0;i < files.length; i++) {
			if (files[i].isFile()) {
				String temp = files[i].getPath();
				pathList.add(temp);
				continue;
			}
			if (files[i].isDirectory()) {
				getPaths(files[i].getPath());
			}
		}
		return pathList;
		
	}
	
	public static void main(String[] args) {
		String path = "/Users/wangpeicai/worksapce/workspace_eclipse/RCMS/WebContent/WEB-INF/etc/jbo";
		GetFilePath.getPaths(path);
	}
	

}
