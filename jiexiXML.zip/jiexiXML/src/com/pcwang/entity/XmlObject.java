package com.pcwang.entity;

public class XmlObject {
	
	//表名
	private String tableName;
	//字段名
	private String colName;
	//字段注释
	private String colLabel;
	private String type;
	private String length;
	private String scale;
	
	
	
	
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getColName() {
		return colName;
	}
	public void setColName(String colName) {
		this.colName = colName;
	}
	public String getColLabel() {
		return colLabel;
	}
	public void setColLabel(String colLabel) {
		this.colLabel = colLabel;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getLength() {
		return length;
	}
	public void setLength(String length) {
		this.length = length;
	}
	public String getScale() {
		return scale;
	}
	public void setScale(String scale) {
		this.scale = scale;
	}
	@Override
	public String toString() {
		return "XmlObject [tableName=" + tableName + ", colName=" + colName + ", colLabel=" + colLabel + ", type="
				+ type + ", length=" + length + ", scale=" + scale + "]";
	}

}
