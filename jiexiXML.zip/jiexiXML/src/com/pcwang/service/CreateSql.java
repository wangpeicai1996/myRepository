package com.pcwang.service;

import java.util.List;
import java.util.Map;

import com.pcwang.entity.XmlObject;
import com.pcwang.util.ReadDataSource;
import com.pcwang.util.ReadFile;

public class CreateSql {

	public void create() {

		try {
			Map<String, List<XmlObject>> xmlMap = ReadFile
					.readFile("/Users/wangpeicai/worksapce/workspace_eclipse/RCMS/WebContent/WEB-INF/etc/jbo");
			int i = 1;
			int j = 1;
			Map<String, Map<String, String>> dataMap = ReadDataSource.queryData();
			List<String> tableList = ReadDataSource.queryTableName();
			for (String tableName : tableList) {
				if (xmlMap.containsKey(tableName)) {
					if (dataMap.containsKey(tableName)) {
						List<XmlObject> xmlObjs = xmlMap.get(tableName);
						for (XmlObject xmlObj : xmlObjs) {
							String colName = xmlObj.getColName();
							String colLabel = xmlObj.getColLabel();
							Map<String, String> dataValue = dataMap.get(tableName);
							if (dataValue.containsKey(colName)) {
								if (colLabel != null) {
									String sql = "COMMENT ON COLUMN " + tableName + "." + colName + " IS '" + colLabel + "';";
									System.out.println(sql);
									i++;
								} else {
									j++;
								}
							}
						}
					}
				}
			}
			System.out.println("生成jbo有注释的语句一共" + i + "条");
			System.out.println("无注释的jbo一共" + j + "条");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {
		CreateSql s = new CreateSql();
		s.create();
	}

}
